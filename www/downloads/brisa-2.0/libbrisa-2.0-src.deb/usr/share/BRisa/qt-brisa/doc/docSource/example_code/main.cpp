#include <QtGui/QApplication>
#include "light.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget window;

    return a.exec();
}
