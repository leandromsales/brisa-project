:mod:`control_point` --- Control Point API
==========================================

.. module: control_point
    :synopsis: API for writing control points


Here you can learn how to use the Control Point package API to subscribe to unicast eventing

.. toctree::
    :numbered:

    service.rst
