***********
 Copyright
***********

BRisa and this documentation is:

Copyright (C) 2007-2010 BRisa Team <brisa-develop@garage.maemo.org>
