.. BRisa UPnP documentation master file, created by sphinx-quickstart on Mon May  4 11:21:11 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

BRisa UPnP's documentation
======================================

.. toctree::
   :maxdepth: 2
   :numbered:

   glossary/index.rst
   about/index.rst
   installation/index.rst
   core/index.rst
   upnp/index.rst
   code_examples.rst
   wizard/wizard.rst
   copyright.rst

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
